import fs from "fs";
import { EmbedBuilder } from "discord.js";

export default {
  name: "waifurank",
  description: "Show all waifu ranked by power",
  async execute({ message, waifusPath }) {
    let waifus = [];
    try { waifus = JSON.parse(fs.readFileSync(waifusPath, "utf8")); } catch {}
    if (!waifus.length) return message.reply("No waifus found!");

    const typeBonus = { fire: 5, ice: 5, heal: 5, physical: 3 };
    waifus.forEach(w => w.power = w.hp + w.attack + w.defense + (typeBonus[w.type] || 0));

    waifus.sort((a,b) => b.power - a.power);
    const top10 = waifus.slice(0, 10);

    const embed = new EmbedBuilder()
      .setTitle("🔥 Top 10 Waifu by Power")
      .setColor(0xff69b4)
      .setDescription(top10.map((w,i) => `${i+1}. ${w.name} (${w.rarity}) - Power: ${w.power}`).join("\n"));

    message.reply({ embeds: [embed] });
  }
};
