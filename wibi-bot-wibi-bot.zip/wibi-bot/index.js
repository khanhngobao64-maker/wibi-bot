import fs from "fs";
import path from "path";
import { Client, GatewayIntentBits, Partials, EmbedBuilder } from "discord.js";

// --- Load config ---
const configPath = path.resolve("./config.json");
const config = JSON.parse(fs.readFileSync(configPath, "utf8"));

// --- Client Discord ---
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ],
  partials: [Partials.Channel]
});

// --- Prefixes ---
const prefixesPath = path.resolve("./data/prefixes.json");
let prefixes = {};
try {
  prefixes = JSON.parse(fs.readFileSync(prefixesPath, "utf8"));
} catch {
  prefixes = {};
}

// --- Waifu data ---
const waifuDataPath = path.resolve("./data/waifuData.json");
let waifuData = {};
try {
  waifuData = JSON.parse(fs.readFileSync(waifuDataPath, "utf8"));
} catch {
  waifuData = {};
}

// --- Commands ---
const commands = new Map();
const commandFiles = fs.readdirSync("./commands").filter(f => f.endsWith(".js"));
for (const file of commandFiles) {
  const { default: cmd } = await import(`./commands/${file}`);
  if (cmd && cmd.name) commands.set(cmd.name, cmd);
}

// --- Event ready ---
client.once("ready", () => {
  console.log(`💖 Wibi Bot sẵn sàng! Đăng nhập thành công: ${client.user.tag}`);
});

// --- Event message ---
client.on("messageCreate", async (message) => {
  if (message.author.bot || !message.guild) return;

  const prefix = prefixes[message.guild.id] ?? config.defaultPrefix;
  if (!message.content.startsWith(prefix)) return;

  const args = message.content.slice(prefix.length).trim().split(/\s+/);
  const cmdName = args.shift()?.toLowerCase();

  const cmd = commands.get(cmdName);
  if
