import fs from "fs";
import { EmbedBuilder } from "discord.js";

export default {
  name: "fight",
  description: "Solo PvP with another user!",
  async execute({ message }) {
    const userId = message.author.id;
    const target = message.mentions.users.first();
    if (!target) return message.reply("Please mention a user to fight!");
    
    const path = './data/inventory.json';
    let inv = {};
    try { inv = JSON.parse(fs.readFileSync(path, 'utf8')); } catch {}

    if (!inv[userId]?.waifus?.length || !inv[target.id]?.waifus?.length) 
      return message.reply("Both players need at least one waifu to fight!");

    const attackerWaifu = inv[userId].waifus[0];
    const defenderWaifu = inv[target.id].waifus[0];

    // tính damage
    const damage = Math.max(attackerWaifu.attack - (defenderWaifu.defense || 0), 0);
    defenderWaifu.hp -= damage;

    // embed kết quả
    const embed = new EmbedBuilder()
      .setTitle(`${message.author.username} attacks ${target.username}`)
      .setDescription(`${attackerWaifu.name} hits ${defenderWaifu.name} for ${damage} damage!\n` +
                      `${defenderWaifu.name} HP left: ${Math.max(defenderWaifu.hp, 0)}`)
      .setColor(0xff0000);

    // check thua
    if (defenderWaifu.hp <= 0) {
      embed.addFields({ name: "🏆 Winner!", value: `${message.author.username} wins!` });
      defenderWaifu.hp = 0;
    }

    fs.writeFileSync(path, JSON.stringify(inv, null, 2));
    message.reply({ embeds: [embed] });
  }
};
