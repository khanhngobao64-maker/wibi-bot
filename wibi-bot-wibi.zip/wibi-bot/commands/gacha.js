import fs from "fs";
import { EmbedBuilder } from "discord.js";

const cooldowns = new Map();

export default {
  name: "gacha",
  description: "Gacha waifu anime!",
  async execute({ message }) {
    const userId = message.author.id;
    const now = Date.now();
    const cooldown = 2 * 60 * 1000; // 2 phút

    if (cooldowns.has(userId) && now - cooldowns.get(userId) < cooldown) {
      const remaining = Math.ceil((cooldown - (now - cooldowns.get(userId))) / 1000);
      return message.reply(`⏳ Bạn phải chờ ${remaining} giây trước khi gacha lần nữa.`);
    }

    cooldowns.set(userId, now);

    const waifus = JSON.parse(fs.readFileSync("./data/waifus.json", "utf8"));

    // random theo rate
    let totalRate = waifus.reduce((sum, w) => sum + w.rate, 0);
    let rand = Math.random() * totalRate;
    let selected;
    for (const w of waifus) {
      rand -= w.rate;
      if (rand <= 0) { selected = w; break; }
    }

    if (!selected) selected = waifus[0];

    // Lưu vào inventory
    const invPath = "./data/inventory.json";
    let inv = {};
    try { inv = JSON.parse(fs.readFileSync(invPath, "utf8")); } catch {}
    if (!inv[userId]) inv[userId] = { waifus: [], gold: 0 };
    inv[userId].waifus.push(selected.name);
    fs.writeFileSync(invPath, JSON.stringify(inv, null, 2));

    const embed = new EmbedBuilder()
      .setTitle(`🎉 You rolled: ${selected.name} (${selected.rarity})`)
      .setDescription(`Series: ${selected.series}\nHP: ${selected.hp}\nSkill: ${selected.skill}`)
      .setImage(selected.image)
      .setColor(0xff69b4);

    message.reply({ embeds: [embed] });
  }
};
