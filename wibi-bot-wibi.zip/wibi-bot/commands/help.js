import { EmbedBuilder } from "discord.js";

export default {
  name: "help",
  description: "Hiển thị danh sách lệnh của bot, phân biệt lệnh owner-only",
  async execute({ message, commands, prefixes, config }) {
    const serverId = message.guild?.id;
    const prefix = prefixes[serverId] || config.defaultPrefix || "wibi";

    const embed = new EmbedBuilder()
      .setTitle("📖 Wibi Bot Help")
      .setDescription(`Sử dụng các lệnh với prefix: \`${prefix}\``)
      .setColor(0x00ffff)
      .setFooter({ text: "💖 🔒 = Owner-only command" });

    for (const cmd of commands.values()) {
      let usage = "";
      let ownerOnly = false;

      // Chỉ định lệnh owner-only
      if (cmd.name === "set" || cmd.name === "prefix") ownerOnly = true;

      // Gợi ý usage cơ bản
      switch (cmd.name) {
        case "help":
          usage = `${prefix}help`;
          break;
        case "gacha":
          usage = `${prefix}gacha`;
          break;
        case "waifurank":
          usage = `${prefix}waifurank`;
          break;
        case "set":
          usage = `${prefix}set <userID> <waifuName> <hp> <atk> <def>`;
          break;
        case "prefix":
          usage = `${prefix}prefix <newPrefix>`;
          break;
        default:
          usage = `${prefix}${cmd.name} [args]`;
      }

      embed.addFields({
        name: `${prefix}${cmd.name}${ownerOnly ? " 🔒" : ""}`,
        value: `Mô tả: ${cmd.description || "Không có mô tả"}\nCú pháp: \`${usage}\``,
        inline: false
      });
    }

    message.reply({ embeds: [embed] });
  }
};
