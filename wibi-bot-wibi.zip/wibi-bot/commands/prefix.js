import fs from "fs";
import { PermissionsBitField } from "discord.js";


export default {
name: "prefix",
description: "Xem, đổi hoặc reset prefix của Wibi Bot.",
async execute({ message, args, prefixes, prefixesPath, config }) {
const guildId = message.guild.id;
const currentPrefix = prefixes[guildId] ?? config.defaultPrefix;


// Hiện prefix hiện tại
if (!args[0]) {
return message.reply(`📍 Prefix hiện tại của server là: \`${currentPrefix}\``);
}


// Reset prefix
if (args[0].toLowerCase() === "reset") {
delete prefixes[guildId];
fs.writeFileSync(prefixesPath, JSON.stringify(prefixes, null, 2), "utf8");
return message.reply(`🔄 Prefix đã được reset về mặc định: \`${config.defaultPrefix}\``);
}


// Đổi prefix mới (chỉ admin hoặc owner)
if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild) && message.author.id !== config.ownerId) {
return message.reply("❗ Bạn cần quyền **Quản lý Server** để đổi prefix.");
}


const newPrefix = args[0];
if (newPrefix.length > 5) return message.reply("⚠️ Prefix không được dài quá 5 ký tự!");


prefixes[guildId] = newPrefix;
fs.writeFileSync(prefixesPath, JSON.stringify(prefixes, null, 2), "utf8");
message.reply(`✅ Đã đổi prefix thành: \`${newPrefix}\``);
}
};