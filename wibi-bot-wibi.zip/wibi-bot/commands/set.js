import fs from "fs";

export default {
  name: "set",
  description: "Chỉnh thông số waifu (Owner-only)",
  async execute({ message, args, waifuData, waifuDataPath, config }) {
    const ownerID = config.ownerId.toString(); // luôn string
    if (message.author.id !== ownerID) {
      return message.reply("❌ Chỉ owner mới có thể dùng lệnh này!");
    }

    if (args.length < 5) {
      return message.reply("❌ Cú pháp: `set <userID> <waifuName> <hp> <atk> <def>`");
    }

    const targetID = args[0];
    const waifuName = args[1];
    const hp = parseInt(args[2]);
    const atk = parseInt(args[3]);
    const def = parseInt(args[4]);

    if (!waifuData[targetID]) {
      return message.reply("❌ Người này chưa có waifu nào.");
    }

    const waifu = waifuData[targetID].find(w => w.name.toLowerCase() === waifuName.toLowerCase());
    if (!waifu) return message.reply("❌ Không tìm thấy waifu này.");

    // Chỉnh thông số
    waifu.hp = hp;
    waifu.atk = atk;
    waifu.def = def;

    // Lưu lại kho
    fs.writeFileSync(waifuDataPath, JSON.stringify(waifuData, null, 2));

    message.reply(`✅ Waifu **${waifu.name}** của <@${targetID}> đã được chỉnh thành: HP=${hp}, ATK=${atk}, DEF=${def}`);
  }
};
