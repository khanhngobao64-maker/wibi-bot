export default {
name: "wibi",
description: "Phản hồi đáng yêu kiểu Wibi~",
async execute({ message }) {
const replies = [
"Wibi~ đang nghe đây 💕",
"UwU~ ai vừa gọi Wibi đó~",
"OwO? Gọi Wibi chi đó~",
"Wibi đến đây 💫"
];
const reply = replies[Math.floor(Math.random() * replies.length)];
message.channel.send(reply);
}
};